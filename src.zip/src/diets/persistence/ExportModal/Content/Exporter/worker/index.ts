// eslint-disable-next-line
import Worker from 'comlink-loader!./worker'

export default Worker
