function MenuOrDrawerSeparator() {
  return null
}

export default MenuOrDrawerSeparator
