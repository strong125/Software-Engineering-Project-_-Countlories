import { ReactElement, ReactNode } from 'react'

type Props = {
  onClick?: () => void
  children: ReactNode
  icon: ReactElement
  isDisabled?: boolean
}

function MenuItem(props: Props) {
  return null
}

export default MenuItem
