type InputType = 'text' | 'nutritionValue' | 'foodCategory'

export type { InputType }
