const Textarea = {
  defaultProps: {
    focusBorderColor: 'teal.400',
  },
}

export default Textarea
